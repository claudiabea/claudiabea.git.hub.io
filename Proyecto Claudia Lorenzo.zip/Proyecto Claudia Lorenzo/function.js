

document.getElementById("boton").onclick, function() {
  console.log("Almagro 2000");
  document.getElementById("demo").innerHTML="domicilio: Almagro 2000"
};


